package aquascan;

import Login.window;


public class Aquascan {


public static void main(String args[]) {
    java.awt.EventQueue.invokeLater(() -> {
        new window().setVisible(true);
    });
}
}


    
